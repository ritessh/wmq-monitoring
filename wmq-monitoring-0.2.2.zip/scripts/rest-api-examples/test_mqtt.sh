#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/mqtt/service/connections/${connection_name}/available"

# check MQTT availability
log_start "Test MQTT availability"
check ${uri}
log_end