#!/bin/sh

# source api functions
. ./rest_api.sh


# URI and data
uri="/rest/metadata/connections"
connection_json_data="connection.json"

# create
log_start "Create connection"
create_json ${connection_json_data} ${uri}
log_end