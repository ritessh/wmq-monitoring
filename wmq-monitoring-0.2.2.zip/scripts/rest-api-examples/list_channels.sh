#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/channels"


# list all channels
log_start "All channels"
get_json ${uri}
log_end

# list ServerConnection channels
log_start "ServerConnection channels"
get_json ${uri}"?type=ServerConnection"
log_end

# list Sender channels
log_start "Sender channels"
get_json ${uri}"?type=Sender"
log_end

# list ServerConnection channels with name filter
log_start "Filtered channels"
get_json ${uri}"?type=ServerConnection&name=CH.*"
log_end


