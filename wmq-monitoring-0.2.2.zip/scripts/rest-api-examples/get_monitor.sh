#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/monitors"


# Get monitor
monitor_name="m1";
log_start "Get monitor ${monitor_name}"
get_json ${uri}/${monitor_name} 
log_end

# Get QMGR monitor
log_start "Get monitor qmgr"
get_json ${uri}/qmgr
log_end