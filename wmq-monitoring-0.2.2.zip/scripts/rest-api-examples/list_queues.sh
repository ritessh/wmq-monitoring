#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/queues"

# list all queues
log_start "List queues"
get_json ${uri}
log_end

# list local queues
log_start "List queues with type filter"
get_json ${uri}"?type=local"
log_end

# list alias queues
log_start "List queues with type filter"
get_json ${uri}"?type=alias"
log_end

# list system remote queues
log_start "List queues with type & name filter"
get_json ${uri}"?type=remote&name=SYSTEM.*"
log_end