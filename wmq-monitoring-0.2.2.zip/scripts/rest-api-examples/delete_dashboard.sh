#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
dashboard_name="d1"
uri="/rest/metadata/dashboards/${dashboard_name}"


# Delete dashboard
log_start "Delete dashboard"
delete ${uri}
log_end