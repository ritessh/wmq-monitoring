#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
uri="/rest/metadata/connections"


# list all connections
log_start "List all connections"
get_json ${uri}
log_end