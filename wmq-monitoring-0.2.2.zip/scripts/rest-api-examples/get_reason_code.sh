#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
uri="/rest/error/codes/mqrc"

# get MQ RC
log_start "RC:2009"
get_json ${uri}/2009
log_end

log_start "RC:2035"
get_json ${uri}/2035
log_end
