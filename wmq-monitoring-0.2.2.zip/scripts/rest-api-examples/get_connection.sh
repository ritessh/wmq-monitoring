#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}"


# Get connection
log_start "Get connection"
get_json ${uri}
log_end