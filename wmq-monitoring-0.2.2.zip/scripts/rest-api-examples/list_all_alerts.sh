#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
uri="/rest/data/alerts"

# All alerts
log_start "List all alerts"
get_json ${uri}
log_end

# All alerts with warn
log_start "List all alerts with warn"
get_json ${uri}"?level=warn"
log_end