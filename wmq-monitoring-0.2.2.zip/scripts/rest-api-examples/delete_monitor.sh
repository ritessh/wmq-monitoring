#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
monitor_name="m1"
uri="/rest/metadata/connections/${connection_name}/monitors/${monitor_name}"

# Delete monitor
log_start "Delete monitor"
delete ${uri}
log_end