#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
dashboard_name="d1"
uri="/rest/metadata/dashboards/${dashboard_name}/monitors"
remove_dashboard_monitors_json_data="remove_dashboard_monitors.json"

# Remove monitors from dashboard
log_start "Remove monitors from dashboard"
delete_json ${remove_dashboard_monitors_json_data} ${uri}
log_end