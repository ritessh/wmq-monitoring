#!/bin/sh

# source api functions
. ./rest_api.sh


#sendingMode: p2p | pubsub
#payload destination: clientId | topic
send_msg()
{
sending_mode=$1
payload=$2
connection_name=$3
do_action_with_data ${payload} "/rest/mqtt/message/${sending_mode}/connections/${connection_name}"
}


connection_name="conn1"
# MQTT: Send message p2p 
log_start "MQTT: Send message p2p"
send_msg "p2p" "mqtt_p2p_msg.json" ${connection_name}
log_end

# MQTT: Send message pub/sub 
log_start "MQTT: Send message pub/sub"
send_msg "pubsub" "mqtt_pubsub_msg.json"  ${connection_name}
log_end
