WMQ Monitoring v0.2.2
-------------------------------------------------

DISTRIBUTION CONTENTS:

- The WAR are available in the 'dist' directory.
- The reference manuals are located in the 'docs' directory.
- The RESTful API examples are located in the 'scripts' directory.


NOTES:

This web-based monitoring tool for IBM® WebSphere® MQ, it targets WebSphere MQ administrators 
and users who would like to take advantage of the monitoring tool features, such as visualization 
of WebSphere MQ system health and custom alert conditions for WebSphere MQ objects, including queues, 
topics, channels, listeners, and queue managers.

It works with IBM® WebSphere® MQ on all platforms, and it's a Java based application that can run on 
any platforms (Windows, Linux, Unix etc.)

It is tested with Apache Tomcat 7 and IBM® WebSphere® Liberty Profile v8.5.5
and not working with IBM® WebSphere® full profile, because of some classloading issues.


IMPORTANT:

Please DO read the wmq-monitoring-userguide.pdf and wmq-monitoring-faq.pdf carefully in the 'docs' 
directory to avoid unnecessary issues.